﻿using UnityEngine;
using System.Collections;



public class gridsnap : MonoBehaviour

{
    public float grid = .5f;
    float x = 5f;
    float y = 0f;
    float z = 6f;

    void Update()
    {
        float reciprocalGrid = 1f / grid;

        x = Mathf.Round(transform.position.x * reciprocalGrid) / reciprocalGrid;
        y = Mathf.Round(transform.position.y * reciprocalGrid) / reciprocalGrid;
        z = Mathf.Round(transform.position.z * reciprocalGrid) / reciprocalGrid;

        transform.position = new Vector3(x, y,z);

    }





}





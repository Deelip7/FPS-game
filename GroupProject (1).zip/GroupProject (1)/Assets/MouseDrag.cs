﻿using UnityEngine;
using System.Collections;


public class MouseDrag : MonoBehaviour
{
    private Vector3 mOffset;
    private float mZCoord;
    public float speed = 1000.0f;
    void OnMouseDown()
    {
        mZCoord = Camera.main.WorldToScreenPoint(gameObject.transform.position).z;

        // Store offset = gameobject world pos - mouse world pos
        mOffset = gameObject.transform.position - GetMouseAsWorldPoint();
    }

    private Vector3 GetMouseAsWorldPoint()
    {
        // Pixel coordinates of mouse (x,y)
        Vector3 mousePoint = Input.mousePosition;
        // z coordinate of game object on screen
        mousePoint.z = mZCoord;
        // Convert it to world points
        return Camera.main.ScreenToWorldPoint(mousePoint);
    }
    void OnMouseDrag()
    {

        float distance_to_screen = Camera.main.WorldToScreenPoint(gameObject.transform.position).z;
        Vector3 before_clamp = Camera.main.ScreenToWorldPoint(new Vector3(
            Input.mousePosition.x,
            Input.mousePosition.y,
            distance_to_screen));
        transform.position = new Vector3(
            Mathf.Clamp(before_clamp.x, -150, 200),
          before_clamp.y,
           Mathf.Clamp(before_clamp.z, -130, 130));


        transform.GetComponent<Rigidbody>().velocity = new Vector3(0, 10, 0);
        //transform.position = GetMouseAsWorldPoint() + mOffset;
    }


}


﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static int currentScore;

    public static int currentLevel = 0;
    public static int unlockedLevel;
    public GameObject youWinText; 

    public static void CompleteLevel()
    {
        if (currentLevel < 1)
        {
            currentLevel += 1;
            SceneManager.LoadScene(currentLevel);
        }
        else
        {

        }
    }
}
 